#!/usr/bin/env python3
"""
ОСАДА — сервер кооператива. Только стандартная библиотека Python 3.8+ (pip ничего ставить не нужно).

Запуск на VDS:
    python3 server.py                  # порт 8080
    PORT=9000 python3 server.py        # другой порт

Положи рядом index.html (игру). Сервер сам отдаёт её по http://IP:ПОРТ/ — адрес сервера в игре подставится сам.
Не забудь открыть порт в фаерволе:  ufw allow 8080/tcp
Для https/wss поставь перед ним nginx/caddy и проксируй путь /ws с заголовками Upgrade.

Сервер — это "ретранслятор": комнаты (до 4 игроков), код комнаты, пересылка сообщений.
Логику зомби считает хост (создатель комнаты), поэтому сервер лёгкий.

Аккаунты (бесплатно, без внешних сервисов): ник + пароль (PBKDF2-SHA256 + соль), без капчи
— отключена; защита от ботов: скрытое поле-ловушка и ограничение попыток по IP. Есть лидерборд и список комнат.
Данные лежат рядом: accounts.json и secret.key (никому не отдавай и делай бэкап).
"""
import asyncio, base64, hashlib, hmac, json, os, random, secrets, struct, time

PORT = int(os.environ.get('PORT', '8080'))
HOST = os.environ.get('HOST', '0.0.0.0')
MAXP = 4
HERE = os.path.dirname(os.path.abspath(__file__))
GUID = b'258EAFA5-E914-47DA-95CA-C5AB0DC85B11'
rooms = {}   # code -> {'host': Client, 'p': {id: Client}}
_next_id = 0


# ======================= АККАУНТЫ =======================
ACC_FILE = os.path.join(HERE, 'accounts.json')
KEY_FILE = os.path.join(HERE, 'secret.key')
try:
    accounts = json.load(open(ACC_FILE, encoding='utf-8'))
except Exception:
    accounts = {}
if os.path.exists(KEY_FILE):
    SECRET = open(KEY_FILE, 'rb').read()
else:
    SECRET = secrets.token_bytes(32)
    open(KEY_FILE, 'wb').write(SECRET)
    try:
        os.chmod(KEY_FILE, 0o600)
    except Exception:
        pass
used_caps = {}
hits = {}   # (kind, ip) -> [timestamps]


def save_accounts():
    tmp = ACC_FILE + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(accounts, f, ensure_ascii=False)
    os.replace(tmp, ACC_FILE)


def sign(txt):
    return base64.urlsafe_b64encode(hmac.new(SECRET, txt.encode(), hashlib.sha256).digest()).decode().rstrip('=')[:32]


def limited(kind, ip, n, per):
    now = time.time()
    L = [t for t in hits.get((kind, ip), []) if now - t < per]
    if len(L) >= n:
        hits[(kind, ip)] = L
        return True
    L.append(now)
    hits[(kind, ip)] = L
    return False


def make_token(nick):
    exp = int(time.time()) + 30 * 86400
    p = base64.urlsafe_b64encode(('%s|%d' % (nick, exp)).encode()).decode().rstrip('=')
    return p + '.' + sign(p)


def check_token(tok):
    try:
        p, sg = str(tok).split('.', 1)
        if not hmac.compare_digest(sign(p), sg):
            return None
        nick, exp = base64.urlsafe_b64decode(p + '=' * (-len(p) % 4)).decode().split('|')
        if int(exp) < time.time() or nick not in accounts:
            return None
        return nick
    except Exception:
        return None


def captcha_new():
    code = ''.join(random.choice('ABCDEFGHJKMNPQRSTUVWXYZ23456789') for _ in range(5))
    exp = int(time.time()) + 300
    nonce = secrets.token_hex(6)
    tok = '%d.%s.%s' % (exp, nonce, sign('cap|%s|%d|%s' % (code, exp, nonce)))
    w, h = 180, 62
    o = ['<svg xmlns="http://www.w3.org/2000/svg" width="%d" height="%d"><rect width="100%%" height="100%%" fill="#10151f"/>' % (w, h)]
    for _ in range(8):
        o.append('<path d="M%d %d Q%d %d %d %d" stroke="hsl(%d,60%%,45%%)" stroke-width="2" fill="none"/>' % (
            random.randint(0, w), random.randint(0, h), random.randint(0, w), random.randint(0, h), random.randint(0, w), random.randint(0, h), random.randint(0, 360)))
    for i, ch in enumerate(code):
        x, y = 16 + i * 30, 42 + random.randint(-6, 6)
        o.append('<text x="%d" y="%d" font-family="Verdana,Arial,sans-serif" font-weight="700" font-size="%d" fill="hsl(%d,75%%,68%%)" transform="rotate(%d %d %d)">%s</text>' % (
            x, y, random.randint(28, 36), random.randint(0, 360), random.randint(-28, 28), x, y, ch))
    for _ in range(45):
        o.append('<circle cx="%d" cy="%d" r="1.3" fill="hsl(%d,50%%,60%%)"/>' % (random.randint(0, w), random.randint(0, h), random.randint(0, 360)))
    o.append('</svg>')
    return tok, base64.b64encode(''.join(o).encode()).decode()


def captcha_ok(tok, ans):
    try:
        exp, nonce, sg = str(tok).split('.')
        exp = int(exp)
        now = time.time()
        for k in [k for k, v in used_caps.items() if v < now]:
            used_caps.pop(k, None)
        if exp < now or tok in used_caps:
            return False
        used_caps[tok] = exp
        return hmac.compare_digest(sign('cap|%s|%d|%s' % (str(ans).strip().upper(), exp, nonce)), sg)
    except Exception:
        return False


def pw_hash(pw, salt):
    return hashlib.pbkdf2_hmac('sha256', pw.encode('utf-8'), salt, 200000).hex()


def valid_nick(n):
    return isinstance(n, str) and 3 <= len(n) <= 14 and all(ch.isalnum() or ch in '_-' for ch in n)


def pub(a):
    return {'nick': a['nick'], 'skin': a.get('skin', 0), 'best': a.get('best', 0), 'kills': a.get('kills', 0), 'games': a.get('games', 0)}


async def api(path, body, ip, w):
    loop = asyncio.get_running_loop()
    if path == '/api/rooms':
        return 200, {'rooms': [{'code': k, 'name': r['name'], 'host': r['host'].name, 'n': len(r['p']), 'max': MAXP, 'state': r['state'], 'wave': r['wave']}
                               for k, r in rooms.items() if r['pub']]}
    if path == '/api/top':
        top = sorted(accounts.values(), key=lambda a: (-a.get('best', 0), -a.get('kills', 0)))[:10]
        return 200, {'top': [{'nick': a['nick'], 'best': a.get('best', 0), 'kills': a.get('kills', 0)} for a in top]}
    if path == '/api/register':
        if body.get('hp'):
            return 400, {'err': 'Ошибка'}
        if limited('reg', ip, 5, 900):
            return 429, {'err': 'Слишком много попыток, подожди 15 минут'}
        nick, pw = body.get('nick', ''), str(body.get('pw', ''))
        if not valid_nick(nick):
            return 400, {'err': 'Ник: 3–14 символов, буквы/цифры/_/-'}
        if not (6 <= len(pw) <= 64):
            return 400, {'err': 'Пароль: от 6 до 64 символов'}
        key = nick.lower()
        if key in accounts:
            return 400, {'err': 'Этот ник уже занят'}
        salt = secrets.token_bytes(16)
        h = await loop.run_in_executor(None, pw_hash, pw, salt)
        accounts[key] = {'nick': nick, 'salt': salt.hex(), 'hash': h, 'created': int(time.time()), 'skin': 0, 'best': 0, 'kills': 0, 'games': 0}
        save_accounts()
        return 200, {'token': make_token(key), 'prof': pub(accounts[key])}
    if path == '/api/login':
        if limited('log', ip, 10, 300):
            return 429, {'err': 'Слишком много попыток, подожди 5 минут'}
        key = str(body.get('nick', '')).lower()
        a = accounts.get(key)
        pw = str(body.get('pw', ''))
        h = await loop.run_in_executor(None, pw_hash, pw, bytes.fromhex(a['salt'] if a else '00' * 16))
        if not a or not hmac.compare_digest(h, a['hash']):
            return 400, {'err': 'Неверный ник или пароль'}
        return 200, {'token': make_token(key), 'prof': pub(a)}
    if path in ('/api/me', '/api/save'):
        key = check_token(body.get('token'))
        if not key:
            return 401, {'err': 'Нужно войти заново'}
        a = accounts[key]
        if path == '/api/save':
            p = body.get('prof') or {}
            try:
                a['skin'] = int(p.get('skin', a.get('skin', 0))) % 16
                a['best'] = max(a.get('best', 0), min(int(p.get('best', 0)), 9999))
                a['kills'] = max(a.get('kills', 0), min(int(p.get('kills', 0)), 10 ** 7))
                a['games'] = max(a.get('games', 0), min(int(p.get('games', 0)), 10 ** 6))
            except (ValueError, TypeError):
                pass
            save_accounts()
        return 200, {'prof': pub(a)}
    return 404, {'err': 'not found'}


def frame(data: bytes, op: int = 1) -> bytes:
    n = len(data)
    h = bytes([0x80 | op])
    if n < 126:
        h += bytes([n])
    elif n < 65536:
        h += bytes([126]) + struct.pack('>H', n)
    else:
        h += bytes([127]) + struct.pack('>Q', n)
    return h + data


async def read_frame(r):
    h = await r.readexactly(2)
    fin, op = h[0] >> 7, h[0] & 15
    masked, ln = h[1] >> 7, h[1] & 127
    if ln == 126:
        ln = struct.unpack('>H', await r.readexactly(2))[0]
    elif ln == 127:
        ln = struct.unpack('>Q', await r.readexactly(8))[0]
    if ln > 262144:
        raise ValueError('frame too big')
    mask = await r.readexactly(4) if masked else None
    d = await r.readexactly(ln) if ln else b''
    if mask and ln:
        m = (mask * (ln // 4 + 1))[:ln]
        d = (int.from_bytes(d, 'big') ^ int.from_bytes(m, 'big')).to_bytes(ln, 'big')
    return fin, op, d


class Client:
    def __init__(self, w):
        global _next_id
        _next_id += 1
        self.id = _next_id
        self.w = w
        self.room = None
        self.name = 'Игрок'
        self.skin = 0

    def send(self, obj):
        try:
            if self.w.transport.get_write_buffer_size() > 2_000_000:
                self.w.close()
                return
            self.w.write(frame(json.dumps(obj, separators=(',', ':'), ensure_ascii=False).encode('utf-8')))
        except Exception:
            pass


def clean_name(s):
    s = ''.join(ch for ch in str(s or '') if ch.isprintable())[:20].strip()
    return s or 'Игрок'


def new_code():
    while True:
        c = ''.join(random.choice('ABCDEFGHJKLMNPQRSTUVWXYZ23456789') for _ in range(5))
        if c not in rooms:
            return c


def join_room(c, code, room):
    room['p'][c.id] = c
    c.room = code


async def on_message(c, m):
    t = m.get('t')
    if t in ('create', 'join') and not c.room:
        acct = check_token(m.get('token'))
        if acct:
            c.name = accounts[acct]['nick']
        elif m.get('guest'):
            c.name = clean_name(m.get('name'))
        else:
            return c.send({'t': 'err', 'm': 'Войди в аккаунт или играй гостем'})
    if t == 'create' and not c.room:
        c.skin = int(m.get('skin') or 0) % 16
        code = new_code()
        rn = clean_name(m.get('rname')) if str(m.get('rname') or '').strip() else c.name + ' — игра'
        rooms[code] = {'host': c, 'p': {}, 'name': rn[:20], 'pub': bool(m.get('pub', True)), 'state': 'lobby', 'wave': 0}
        join_room(c, code, rooms[code])
        c.send({'t': 'room', 'code': code, 'id': c.id, 'host': True})
    elif t == 'join' and not c.room:
        code = str(m.get('code') or '').upper().strip()
        room = rooms.get(code)
        if not room:
            return c.send({'t': 'err', 'm': 'Комната не найдена'})
        if len(room['p']) >= MAXP:
            return c.send({'t': 'err', 'm': 'Комната заполнена (макс. %d)' % MAXP})
        c.skin = int(m.get('skin') or 0) % 16
        others = [{'id': p.id, 'name': p.name, 'skin': p.skin} for p in room['p'].values()]
        join_room(c, code, room)
        c.send({'t': 'room', 'code': code, 'id': c.id, 'host': False, 'hid': room['host'].id})
        c.send({'t': 'peers', 'list': others})
        for p in room['p'].values():
            if p is not c:
                p.send({'t': 'peer', 'id': c.id, 'name': c.name, 'skin': c.skin})
    elif t == 'meta':
        room = rooms.get(c.room)
        if room and room['host'] is c:
            room['state'] = str(m.get('state', ''))[:8]
            try:
                room['wave'] = int(m.get('wave', 0) or 0)
            except (ValueError, TypeError):
                pass
    elif c.room and c.room in rooms:
        room = rooms[c.room]
        to = m.pop('to', None)
        m['from'] = c.id
        if to is None:
            for p in room['p'].values():
                if p is not c:
                    p.send(m)
        elif to == 'h':
            room['host'].send(m)
        else:
            p = room['p'].get(to)
            if p:
                p.send(m)


async def leave(c):
    room = rooms.get(c.room) if c.room else None
    if not room:
        return
    room['p'].pop(c.id, None)
    if room['host'] is c:
        for p in list(room['p'].values()):
            p.send({'t': 'closed'})
            p.room = None
        rooms.pop(c.room, None)
    else:
        for p in room['p'].values():
            p.send({'t': 'left', 'id': c.id})
        if not room['p']:
            rooms.pop(c.room, None)


async def ws_session(r, w, hd):
    key = hd.get('sec-websocket-key', '')
    acc = base64.b64encode(hashlib.sha1(key.encode() + GUID).digest()).decode()
    w.write(('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n'
             'Sec-WebSocket-Accept: %s\r\n\r\n' % acc).encode())
    await w.drain()
    c = Client(w)
    buf = b''
    try:
        while True:
            fin, op, d = await read_frame(r)
            if op == 8:
                break
            if op == 9:
                w.write(frame(d, 10))
                continue
            if op in (0, 1):
                buf += d
                if len(buf) > 262144:
                    break
                if not fin:
                    continue
                raw, buf = buf, b''
                try:
                    m = json.loads(raw.decode('utf-8'))
                    if isinstance(m, dict):
                        await on_message(c, m)
                except (ValueError, UnicodeDecodeError):
                    pass
    except (asyncio.IncompleteReadError, ConnectionError, ValueError, OSError):
        pass
    finally:
        await leave(c)
        try:
            w.close()
        except Exception:
            pass


async def serve_http(w, path, method='GET', body=None, ip='?'):
    path = path.split('?')[0]
    if path.startswith('/api/'):
        code, obj = await api(path, body or {}, ip, w)
        data = json.dumps(obj, ensure_ascii=False).encode('utf-8')
        w.write(('HTTP/1.1 %d X\r\nContent-Type: application/json; charset=utf-8\r\nContent-Length: %d\r\nCache-Control: no-store\r\nConnection: close\r\n\r\n' % (code, len(data))).encode() + data)
        await w.drain()
        w.close()
        return
    if path in ('/', '/index.html'):
        f = os.path.join(HERE, 'index.html')
        if os.path.exists(f):
            body = open(f, 'rb').read()
            hdr = 'HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: %d\r\nCache-Control: no-cache\r\nConnection: close\r\n\r\n' % len(body)
            w.write(hdr.encode() + body)
        else:
            body = 'Положи index.html рядом с server.py'.encode('utf-8')
            w.write(('HTTP/1.1 404 Not Found\r\nContent-Type: text/plain; charset=utf-8\r\nContent-Length: %d\r\nConnection: close\r\n\r\n' % len(body)).encode() + body)
    elif path == '/health':
        body = json.dumps({'rooms': len(rooms)}).encode()
        w.write(('HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nContent-Length: %d\r\nConnection: close\r\n\r\n' % len(body)).encode() + body)
    else:
        w.write(b'HTTP/1.1 404 Not Found\r\nContent-Length: 0\r\nConnection: close\r\n\r\n')
    await w.drain()
    w.close()


async def handler(r, w):
    try:
        head = await asyncio.wait_for(r.readuntil(b'\r\n\r\n'), 10)
        lines = head.decode('latin1').split('\r\n')
        parts = lines[0].split(' ')
        hd = {}
        for l in lines[1:]:
            if ':' in l:
                k, v = l.split(':', 1)
                hd[k.strip().lower()] = v.strip()
        if hd.get('upgrade', '').lower() == 'websocket':
            await ws_session(r, w, hd)
        else:
            ip = hd.get('x-forwarded-for', '').split(',')[0].strip() or (w.get_extra_info('peername') or ('?',))[0]
            body = {}
            ln = int(hd.get('content-length', '0') or 0)
            if 0 < ln <= 4096:
                try:
                    body = json.loads((await asyncio.wait_for(r.readexactly(ln), 10)).decode('utf-8'))
                except Exception:
                    body = {}
            await serve_http(w, parts[1] if len(parts) > 1 else '/', parts[0], body if isinstance(body, dict) else {}, ip)
    except Exception:
        try:
            w.close()
        except Exception:
            pass


async def main():
    srv = await asyncio.start_server(handler, HOST, PORT)
    print('ОСАДА: сервер запущен на http://%s:%d  (WebSocket: /ws)' % (HOST, PORT), flush=True)
    async with srv:
        await srv.serve_forever()


if __name__ == '__main__':
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        pass
